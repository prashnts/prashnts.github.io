var group__pf__cofold =
[
    [ "part_func_co.h", "part__func__co_8h.html", null ],
    [ "vrna_dimer_pf_s", "group__pf__cofold.html#structvrna__dimer__pf__s", [
      [ "F0AB", "group__pf__cofold.html#a82e31d1fb6e95923fab6036f52c370af", null ],
      [ "FAB", "group__pf__cofold.html#a01a87f59db2b7fbf883b056e6f6c673a", null ],
      [ "FcAB", "group__pf__cofold.html#a7b01cea5721f61badebc29cf0a9c4266", null ],
      [ "FA", "group__pf__cofold.html#a1aca57247f2c023d08028b1919005b0a", null ],
      [ "FB", "group__pf__cofold.html#ab4d307be5400604d3c1d84d58a9981df", null ]
    ] ],
    [ "vrna_dimer_conc_s", "group__pf__cofold.html#structvrna__dimer__conc__s", [
      [ "A0", "group__pf__cofold.html#a9722115f1a483583beaf7ef0f8180087", null ],
      [ "B0", "group__pf__cofold.html#a5231715f610413dd5a88bc9f958cf5f3", null ],
      [ "ABc", "group__pf__cofold.html#aef56a1fe8d7f07e7b5d9a65417dda8a4", null ]
    ] ],
    [ "vrna_dimer_pf_t", "group__pf__cofold.html#ga444df1587c9a2ca15b8eb25188f629c3", null ],
    [ "vrna_dimer_conc_t", "group__pf__cofold.html#gac48c2723444ecfdceafcfd525ca98322", null ],
    [ "vrna_pf_dimer", "group__pf__cofold.html#ga4e5c7d06c302a7c59fc0d64dc142ca63", null ],
    [ "vrna_pf_dimer_probs", "group__pf__cofold.html#gaf04708a63d2385d5959db9f886741479", null ],
    [ "vrna_pf_dimer_concentrations", "group__pf__cofold.html#ga83b8d5d0f7875d6d5013b208f23e3356", null ],
    [ "mirnatog", "group__pf__cofold.html#gaff27888c4088cc1f60fd59cbd589474c", null ],
    [ "F_monomer", "group__pf__cofold.html#gac2d1851a710a8561390861155ca988fe", null ]
];