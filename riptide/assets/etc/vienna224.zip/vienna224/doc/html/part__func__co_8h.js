var part__func__co_8h =
[
    [ "vrna_dimer_pf_t", "group__pf__cofold.html#ga444df1587c9a2ca15b8eb25188f629c3", null ],
    [ "vrna_dimer_conc_t", "group__pf__cofold.html#gac48c2723444ecfdceafcfd525ca98322", null ],
    [ "vrna_pf_dimer", "group__pf__cofold.html#ga4e5c7d06c302a7c59fc0d64dc142ca63", null ],
    [ "vrna_pf_dimer_probs", "group__pf__cofold.html#gaf04708a63d2385d5959db9f886741479", null ],
    [ "vrna_pf_dimer_concentrations", "group__pf__cofold.html#ga83b8d5d0f7875d6d5013b208f23e3356", null ],
    [ "co_pf_fold", "part__func__co_8h.html#ae5c1e7331718669bdae7a86de2be6184", null ],
    [ "co_pf_fold_par", "part__func__co_8h.html#aabfc6cb6d02b8f08ac4c92f4f5b125d9", null ],
    [ "get_plist", "part__func__co_8h.html#a162b6177b14a4156172105a34c09f278", null ],
    [ "compute_probabilities", "part__func__co_8h.html#a21f8f4a97f904d5d805d571081b2f5f9", null ],
    [ "get_concentrations", "part__func__co_8h.html#a163159722a422ba90335a601fc34b8fb", null ],
    [ "init_co_pf_fold", "part__func__co_8h.html#aa12dda9dd6179cdd22bcce87c0682c07", null ],
    [ "export_co_bppm", "part__func__co_8h.html#ad94c0133157bed6912fe7fe866e0039e", null ],
    [ "free_co_pf_arrays", "part__func__co_8h.html#ade3ce34ae8214811374b1d28a40dc247", null ],
    [ "update_co_pf_params", "part__func__co_8h.html#a6e0f36c1f9b7d9dd4bfbad914c1119e5", null ],
    [ "update_co_pf_params_par", "part__func__co_8h.html#a75465d7e8793db68a434d83df9a2e794", null ],
    [ "mirnatog", "group__pf__cofold.html#gaff27888c4088cc1f60fd59cbd589474c", null ],
    [ "F_monomer", "group__pf__cofold.html#gac2d1851a710a8561390861155ca988fe", null ]
];