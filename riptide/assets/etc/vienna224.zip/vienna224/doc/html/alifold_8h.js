var alifold_8h =
[
    [ "vrna_alifold", "group__consensus__mfe__fold.html#ga02098d0c8790f9a37fbef6ad0cfc705c", null ],
    [ "vrna_circalifold", "group__consensus__mfe__fold.html#ga01ce2cff93ea44c4f4254760ca2bd16c", null ],
    [ "vrna_pf_alifold", "group__consensus__pf__fold.html#gaef750636c70e597a85ee139197a4350d", null ],
    [ "vrna_pf_circalifold", "group__consensus__pf__fold.html#ga017209394a4c1e68d96cd47e61d16d25", null ],
    [ "alifold", "group__consensus__mfe__fold.html#ga4cf00f0659e5f0480335d69e797f05b1", null ],
    [ "circalifold", "group__consensus__mfe__fold.html#gadbd3b0b1c144cbfb4efe704b2b260f96", null ],
    [ "free_alifold_arrays", "group__consensus__mfe__fold.html#ga72095e4554b5d577250ea14c42acc49e", null ],
    [ "energy_of_alistruct", "group__consensus__fold.html#ga1c48869c03b49a342bf4cbdd61900081", null ],
    [ "alipf_fold_par", "group__consensus__pf__fold.html#ga5e8d54e41bf3d5b6e535d5bdb33c416e", null ],
    [ "alipf_fold", "group__consensus__pf__fold.html#gaa150d3ba7b009a1c27cb6f0eb197f6b4", null ],
    [ "alipf_circ_fold", "group__consensus__pf__fold.html#gaadd8d570442f86cbbc4978c8c62c9646", null ],
    [ "export_ali_bppm", "group__consensus__pf__fold.html#ga11b6ab8bd9be1821fea352b190a01cab", null ],
    [ "free_alipf_arrays", "group__consensus__pf__fold.html#ga0c0498f35686e26b38ee460d3db1a661", null ],
    [ "alipbacktrack", "group__consensus__stochbt.html#ga0df40248788f0fb17ebdc59d74116d1c", null ],
    [ "get_alipf_arrays", "group__consensus__fold.html#ga5349960075b1847720a2e9df021e2675", null ],
    [ "update_alifold_params", "group__consensus__fold.html#gac484c6bd429bafbd353b91044508d8e9", null ],
    [ "cv_fact", "group__consensus__fold.html#gaf3cbac6ff5d706d6e414677841ddf94c", null ],
    [ "nc_fact", "group__consensus__fold.html#ga502948a122a2af5b914355b1f3ea2f61", null ]
];