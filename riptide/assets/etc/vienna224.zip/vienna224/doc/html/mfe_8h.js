var mfe_8h =
[
    [ "vrna_mfe", "group__mfe__fold.html#gabd3b147371ccf25c577f88bbbaf159fd", null ],
    [ "vrna_mfe_dimer", "group__mfe__cofold.html#gaab22d10c1190f205f16a77cab9d5d3ee", null ],
    [ "vrna_mfe_window", "group__local__mfe__fold.html#ga689df235a1915a1ad56e377383c044ce", null ],
    [ "vrna_mfe_window_zscore", "group__local__mfe__fold.html#gaa4f67ae94efd08d800c17f9b53423fd6", null ]
];