var 2Dpfold_8h =
[
    [ "TwoDpfold_vars", "structTwoDpfold__vars.html", "structTwoDpfold__vars" ],
    [ "vrna_sol_TwoD_pf_t", "group__kl__neighborhood__pf.html#ga5e449fbd695406aabd2bcabddc374621", null ],
    [ "vrna_pf_TwoD", "group__kl__neighborhood__pf.html#ga0bc3427689bd09da09b8b3094a27f836", null ],
    [ "vrna_pbacktrack_TwoD", "group__kl__neighborhood__stochbt.html#ga14aceef73f83bbde77bb3a0ca06c9d13", null ],
    [ "vrna_pbacktrack5_TwoD", "group__kl__neighborhood__stochbt.html#ga6504913303bc325659c365d5f59b41e0", null ],
    [ "get_TwoDpfold_variables", "2Dpfold_8h.html#a1aca740e2a75ab2b2951538266e53d64", null ],
    [ "destroy_TwoDpfold_variables", "2Dpfold_8h.html#afe994291458ee2ac34d3eb825ef62a15", null ],
    [ "TwoDpfoldList", "2Dpfold_8h.html#a692243dac482a1e158a8e1b7881cfda2", null ],
    [ "TwoDpfold_pbacktrack", "2Dpfold_8h.html#ae251288f50dd4ae7d315af0085775f71", null ],
    [ "TwoDpfold_pbacktrack5", "2Dpfold_8h.html#a13430ac6a7f90df426774f131647d2c7", null ]
];