var group__mfe__cofold =
[
    [ "cofold.h", "cofold_8h.html", null ],
    [ "vrna_cofold", "group__mfe__cofold.html#ga45515db181f17653ef7ef5487ef36d08", null ],
    [ "cofold", "group__mfe__cofold.html#gabc8517f22cfe70595ee81fc837910d52", null ],
    [ "cofold_par", "group__mfe__cofold.html#ga7612cfeeb1b793f1e4179b1eb53df1f3", null ],
    [ "free_co_arrays", "group__mfe__cofold.html#gaafb33d7473eb9af9d1b168ca8761c41a", null ],
    [ "update_cofold_params", "group__mfe__cofold.html#ga4fcbf34e77b99bfbb2333d2ab0c41a57", null ],
    [ "update_cofold_params_par", "group__mfe__cofold.html#gaaadbd28b4e428710529ab4098fdacad3", null ],
    [ "export_cofold_arrays_gq", "group__mfe__cofold.html#ga5f5bf4df35d0554f6ace9579f8744c48", null ],
    [ "export_cofold_arrays", "group__mfe__cofold.html#ga5cb6b59983f1f74ccc00b9b9c4e84482", null ],
    [ "get_monomere_mfes", "group__mfe__cofold.html#ga4958b517c613e4d2afd5bce6c1060a79", null ],
    [ "initialize_cofold", "group__mfe__cofold.html#gafee0c32208aa2ac97338b6e3fbad7fa5", null ],
    [ "vrna_mfe_dimer", "group__mfe__cofold.html#gaab22d10c1190f205f16a77cab9d5d3ee", null ]
];