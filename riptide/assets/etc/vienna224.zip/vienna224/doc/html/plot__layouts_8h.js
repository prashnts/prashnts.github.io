var plot__layouts_8h =
[
    [ "VRNA_PLOT_TYPE_SIMPLE", "group__plotting__utils.html#gae6d17b9f0a53cf5205a9181e0f8422e9", null ],
    [ "VRNA_PLOT_TYPE_NAVIEW", "group__plotting__utils.html#ga94d4c863ecac2f220f76658afb92f964", null ],
    [ "VRNA_PLOT_TYPE_CIRCULAR", "group__plotting__utils.html#ga8c9eac631348da92136c8363ecdd9fb9", null ],
    [ "simple_xy_coordinates", "group__plotting__utils.html#gaf4b9173e7d3fd361c3c85e6def194123", null ],
    [ "simple_circplot_coordinates", "group__plotting__utils.html#gac4ea13d35308f09940178d2b05a248c2", null ],
    [ "rna_plot_type", "group__plotting__utils.html#ga5964c4581431b098b80027d6e14dcdd4", null ]
];