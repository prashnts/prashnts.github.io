var group__direct__paths_structvrna__path__s =
[
    [ "en", "group__direct__paths.html#ac25160bf31d28097358278f367e41227", null ],
    [ "s", "group__direct__paths.html#a141b70a59cb81d10bc65bbb7a0f6db77", null ]
];