var group__energy__parameters_structvrna__exp__param__s =
[
    [ "id", "group__energy__parameters.html#a378d5bcf2bae1f3ec84c912c7d3908d2", null ],
    [ "pf_scale", "group__energy__parameters.html#a53c12f0d74f94ce371e0471a8ab5a377", null ],
    [ "temperature", "group__energy__parameters.html#a674656d65ea957ddbeff8bd146b7fc16", null ],
    [ "alpha", "group__energy__parameters.html#a77145830b7bb01b36c3217b363310ef0", null ],
    [ "model_details", "group__energy__parameters.html#ac18055127bccc27c1223f1d2f3b01b53", null ]
];