var Lfold_8h =
[
    [ "vrna_Lfold", "group__local__mfe__fold.html#ga4918cce52bf69c1913cda503b2ac75d8", null ],
    [ "vrna_Lfoldz", "group__local__mfe__fold.html#ga27fddda5fc63eb49c861e38845fc34b4", null ],
    [ "aliLfold", "group__local__consensus__fold.html#ga20a173a3cdb83f5d1778e36c1a6b1f2b", null ],
    [ "Lfold", "group__local__mfe__fold.html#ga16e5a70e60835bb969eaecbe6482f1be", null ],
    [ "Lfoldz", "group__local__mfe__fold.html#gab6d79eecc180f586679f7b85cce5cbe9", null ]
];