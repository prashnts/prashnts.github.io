var group__paths =
[
    [ "Direct refolding paths between two secondary structures", "group__direct__paths.html", "group__direct__paths" ]
];