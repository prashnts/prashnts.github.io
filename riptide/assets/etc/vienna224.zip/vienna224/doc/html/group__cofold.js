var group__cofold =
[
    [ "MFE Structures of two hybridized Sequences", "group__mfe__cofold.html", "group__mfe__cofold" ],
    [ "Partition Function for two hybridized Sequences", "group__pf__cofold.html", "group__pf__cofold" ],
    [ "Partition Function for two hybridized Sequences as a stepwise Process", "group__up__cofold.html", "group__up__cofold" ]
];