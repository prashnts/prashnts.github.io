var searchData=
[
  ['vrna_5fmx_5f2dfold',['VRNA_MX_2DFOLD',['../group__dp__matrices.html#gga6042ea1d58d01931e959791be6d89343ae656f8391445ff71bed8a597a0a19417',1,'dp_matrices.h']]],
  ['vrna_5fmx_5fdefault',['VRNA_MX_DEFAULT',['../group__dp__matrices.html#gga6042ea1d58d01931e959791be6d89343aafa2568956dab79595521e20c49a5f75',1,'dp_matrices.h']]],
  ['vrna_5fmx_5fwindow',['VRNA_MX_WINDOW',['../group__dp__matrices.html#gga6042ea1d58d01931e959791be6d89343a2ea5d5947f6ec02544934b0ff2785e99',1,'dp_matrices.h']]],
  ['vrna_5fvc_5ftype_5falignment',['VRNA_VC_TYPE_ALIGNMENT',['../group__fold__compound.html#gga01a4ff86fa71deaaa5d1abbd95a1447da056345f1bcfe7cd595d1fd437c05246d',1,'data_structures.h']]],
  ['vrna_5fvc_5ftype_5fsingle',['VRNA_VC_TYPE_SINGLE',['../group__fold__compound.html#gga01a4ff86fa71deaaa5d1abbd95a1447da1608d3aa78905fc39e0d25a624ac9512',1,'data_structures.h']]]
];
