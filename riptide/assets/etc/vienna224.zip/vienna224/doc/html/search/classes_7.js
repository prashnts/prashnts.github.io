var searchData=
[
  ['snoopt',['snoopT',['../group__data__structures.html#structsnoopT',1,'']]],
  ['swstring',['swString',['../structswString.html',1,'']]]
];
