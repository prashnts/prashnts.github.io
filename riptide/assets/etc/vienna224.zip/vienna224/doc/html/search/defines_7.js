var searchData=
[
  ['turn',['TURN',['../energy__const_8h.html#ae646250fd59311356c7e5722a81c3a96',1,'energy_const.h']]]
];
