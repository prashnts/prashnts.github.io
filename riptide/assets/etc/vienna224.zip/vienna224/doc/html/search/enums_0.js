var searchData=
[
  ['vrna_5ffc_5ftype_5fe',['vrna_fc_type_e',['../group__fold__compound.html#ga01a4ff86fa71deaaa5d1abbd95a1447d',1,'data_structures.h']]],
  ['vrna_5fmx_5ftype_5fe',['vrna_mx_type_e',['../group__dp__matrices.html#ga6042ea1d58d01931e959791be6d89343',1,'dp_matrices.h']]]
];
