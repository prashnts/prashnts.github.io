var searchData=
[
  ['gquad_2eh',['gquad.h',['../gquad_8h.html',1,'']]]
];
