var searchData=
[
  ['duplext',['duplexT',['../group__data__structures.html#structduplexT',1,'']]],
  ['dupvar',['dupVar',['../group__data__structures.html#structdupVar',1,'']]]
];
