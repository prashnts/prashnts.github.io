var searchData=
[
  ['input_20_2f_20output_20file_20formats',['Input / Output File Formats',['../file_formats.html',1,'']]],
  ['i',['i',['../group__aln__utils.html#ab91db0a87ef8402dc151795ba5a64c6f',1,'vrna_pinfo_s::i()'],['../group__data__structures.html#ab6d031a21388be8763b75ea74c937f17',1,'interact::i()'],['../group__data__structures.html#a8ca0da20536780589fb3e3472ca0581f',1,'pu_contrib::I()']]],
  ['id',['id',['../group__energy__parameters.html#a378d5bcf2bae1f3ec84c912c7d3908d2',1,'vrna_exp_param_s']]],
  ['iindx',['iindx',['../group__fold__compound.html#afdead4cf55c882d3497e779573e17e03',1,'vrna_fc_s::iindx()'],['../fold__vars_8h.html#a92089ae3a51b5d75a14ce9cc29cc8317',1,'iindx():&#160;fold_vars.h']]],
  ['inf',['INF',['../energy__const_8h.html#a12c2040f25d8e3a7b9e1c2024c618cb6',1,'energy_const.h']]],
  ['init_5fco_5fpf_5ffold',['init_co_pf_fold',['../part__func__co_8h.html#aa12dda9dd6179cdd22bcce87c0682c07',1,'part_func_co.h']]],
  ['init_5fpf_5ffold',['init_pf_fold',['../part__func_8h.html#a15176e23eceeff8c7d14eabcfec8a2af',1,'part_func.h']]],
  ['init_5fpf_5ffoldlp',['init_pf_foldLP',['../LPfold_8h.html#ae85bf55053e9fb295208be322e0fa07a',1,'LPfold.h']]],
  ['init_5frand',['init_rand',['../utils_8h.html#a8aaa6d9be6f803f496d9b97375c371f3',1,'utils.h']]],
  ['initialize_5fcofold',['initialize_cofold',['../group__mfe__cofold.html#gafee0c32208aa2ac97338b6e3fbad7fa5',1,'cofold.h']]],
  ['initialize_5ffold',['initialize_fold',['../group__mfe__fold__single.html#gac3f0a28d9cb609d388b155445073fd20',1,'fold.h']]],
  ['int_5furn',['int_urn',['../utils_8h.html#a68ff0849d44f62fe491800378a5ffcb4',1,'utils.h']]],
  ['interact',['interact',['../group__data__structures.html#structinteract',1,'']]],
  ['interior_5floops_2eh',['interior_loops.h',['../interior__loops_8h.html',1,'']]],
  ['inv_5fverbose',['inv_verbose',['../group__inverse__fold.html#gafcfc65fba01b9cca5946726ed9057a63',1,'inverse.h']]],
  ['inverse_2eh',['inverse.h',['../inverse_8h.html',1,'']]],
  ['inverse_5ffold',['inverse_fold',['../group__inverse__fold.html#ga7af026de55d4babad879f2c92559cbbc',1,'inverse_fold(char *start, const char *target):&#160;inverse.h'],['../group__inverse__fold.html',1,'(Global Namespace)']]],
  ['inverse_5fpf_5ffold',['inverse_pf_fold',['../group__inverse__fold.html#gaeef52ecbf2a2450ad585a344f9826806',1,'inverse.h']]]
];
