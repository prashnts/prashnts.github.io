var searchData=
[
  ['data_5fstructures_2eh',['data_structures.h',['../data__structures_8h.html',1,'']]],
  ['dist_5fvars_2eh',['dist_vars.h',['../dist__vars_8h.html',1,'']]],
  ['dp_5fmatrices_2eh',['dp_matrices.h',['../dp__matrices_8h.html',1,'']]],
  ['duplex_2eh',['duplex.h',['../duplex_8h.html',1,'']]]
];
