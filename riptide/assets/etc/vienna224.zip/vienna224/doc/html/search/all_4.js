var searchData=
[
  ['b0',['B0',['../group__pf__cofold.html#a5231715f610413dd5a88bc9f958cf5f3',1,'vrna_dimer_conc_s']]],
  ['b2c',['b2C',['../group__struct__utils.html#ga9c80d92391f2833549a8b6dac92233f0',1,'RNAstruct.h']]],
  ['b2hit',['b2HIT',['../group__struct__utils.html#ga07b7e90e712559a1992fba3ac6d21bbd',1,'RNAstruct.h']]],
  ['b2shapiro',['b2Shapiro',['../group__struct__utils.html#ga5cd2feb367feeacad0c03cb7ddba5f10',1,'RNAstruct.h']]],
  ['backtrack',['backtrack',['../group__model__details.html#a31f4471608cbdd03887f63c281823adb',1,'vrna_md_s']]],
  ['backtrack_5fgquad_5fintloop',['backtrack_GQuad_IntLoop',['../group__loops.html#ga220c41e8dbcee940ac975b8ce88e55c5',1,'gquad.h']]],
  ['backtrack_5fgquad_5fintloop_5fl',['backtrack_GQuad_IntLoop_L',['../group__loops.html#ga7b371308fa5a45c7ac353ef6ed1014de',1,'gquad.h']]],
  ['backtrack_5ftype',['backtrack_type',['../group__model__details.html#abb265da25121d22ed11c8435861f0e53',1,'vrna_md_s::backtrack_type()'],['../group__model__details.html#ga83bdb43472a259c71e69fa9f70f420c3',1,'backtrack_type():&#160;model.h']]],
  ['base_5fpair',['base_pair',['../fold__vars_8h.html#a0244a629b5ab4f58b77590c3dfd130dc',1,'fold_vars.h']]],
  ['betascale',['betaScale',['../group__model__details.html#a19524bf1d8d7ab590ed36edbbcaaba2c',1,'vrna_md_s']]],
  ['boltzmann_5fsampling_2eh',['boltzmann_sampling.h',['../boltzmann__sampling_8h.html',1,'']]],
  ['bondt',['bondT',['../group__data__structures.html#gaaeed53a7508c6ce549a98223e94b25df',1,'data_structures.h']]],
  ['bonus',['BONUS',['../energy__const_8h.html#a96a9822fa134450197dd454b1478a193',1,'energy_const.h']]],
  ['bp',['bp',['../group__aln__utils.html#aa5feac5559b36dcd7cb38111c45d444d',1,'vrna_pinfo_s']]],
  ['bp_5fdistance',['bp_distance',['../group__struct__utils.html#ga6ebbcd29a754f0e4f1a66d1fd84184db',1,'structure_utils.h']]],
  ['bpdist',['bpdist',['../group__kl__neighborhood__mfe.html#af1106e1a592e2dccc92b3452340549e0',1,'TwoDfold_vars::bpdist()'],['../structTwoDpfold__vars.html#accef8eaa05fa57ca33aa22cbc7b7aaff',1,'TwoDpfold_vars::bpdist()'],['../group__fold__compound.html#a5c53e55583ce096148075bc240fc2bce',1,'vrna_fc_s::bpdist()']]],
  ['bppm_5fsymbol',['bppm_symbol',['../group__struct__utils.html#ga49962ad6242b8c628de6ca16bb831c1d',1,'structure_utils.h']]],
  ['bppm_5fto_5fstructure',['bppm_to_structure',['../group__struct__utils.html#ga129d81c4a1ead793c5b2311333e03dfa',1,'structure_utils.h']]],
  ['bt',['bt',['../group__soft__constraints.html#a2a2aca01782c2b980d7b7fd05b9be89c',1,'vrna_sc_s']]],
  ['bug_20list',['Bug List',['../bug.html',1,'']]],
  ['bibliography',['Bibliography',['../citelist.html',1,'']]]
];
