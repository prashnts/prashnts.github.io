var searchData=
[
  ['maxdos',['MAXDOS',['../subopt_8h.html#a5ec740b80afb4906ba4311dbd8ddbd89',1,'subopt.h']]],
  ['maxloop',['MAXLOOP',['../energy__const_8h.html#ad1bd6eabac419670ddd3c9ed82145988',1,'energy_const.h']]]
];
