var searchData=
[
  ['n_5fseq',['n_seq',['../group__fold__compound.html#a614702ab74478e786272be44f8cebfe3',1,'vrna_fc_s']]],
  ['naview_2eh',['naview.h',['../naview_8h.html',1,'']]],
  ['nbpairs',['NBPAIRS',['../energy__const_8h.html#a5e75221c779d618eab81e096f37e32ce',1,'energy_const.h']]],
  ['nc_5ffact',['nc_fact',['../group__consensus__fold.html#ga502948a122a2af5b914355b1f3ea2f61',1,'alifold.h']]],
  ['no_5fclosinggu',['no_closingGU',['../group__model__details.html#gaa8d1c7b92489179e1eafa562b7bdd259',1,'model.h']]],
  ['node',['node',['../group__data__structures.html#structnode',1,'']]],
  ['nogu',['noGU',['../group__model__details.html#ad64a5eaf9c4550e7525b36a725fec4b2',1,'vrna_md_s::noGU()'],['../group__model__details.html#gabf380d09e4f1ab94fc6af57cf0ad5d32',1,'noGU():&#160;model.h']]],
  ['noguclosure',['noGUclosure',['../group__model__details.html#a7e883db1f33f8f3baa5c9b140350c78e',1,'vrna_md_s']]],
  ['nolonelypairs',['noLonelyPairs',['../group__model__details.html#ga097eccaabd6ae8b4fef83cccff85bb5d',1,'model.h']]],
  ['nolp',['noLP',['../group__model__details.html#a753200bf21cee0ea2df64afe43999f5d',1,'vrna_md_s']]],
  ['nonstandards',['nonstandards',['../group__model__details.html#a25cb894b76ec876a679a45448dea5b0f',1,'vrna_md_s::nonstandards()'],['../group__model__details.html#ga2695d91cc535d09c2eae5c3884e2ec64',1,'nonstandards():&#160;model.h']]],
  ['nrerror',['nrerror',['../utils_8h.html#a127ce946e56b5a5773781cabe68e38c5',1,'utils.h']]]
];
