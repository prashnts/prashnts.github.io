var group__local__fold =
[
    [ "Local MFE structure Prediction and Z-scores", "group__local__mfe__fold.html", "group__local__mfe__fold" ],
    [ "Partition functions for locally stable secondary structures", "group__local__pf__fold.html", "group__local__pf__fold" ],
    [ "Local MFE consensus structures for Sequence Alignments", "group__local__consensus__fold.html", "group__local__consensus__fold" ],
    [ "Lfold.h", "Lfold_8h.html", null ]
];