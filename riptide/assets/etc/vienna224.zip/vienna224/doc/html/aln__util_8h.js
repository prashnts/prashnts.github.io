var aln__util_8h =
[
    [ "vrna_pinfo_t", "group__aln__utils.html#ga6660dfca23debee7306e0cd53341263f", null ],
    [ "pair_info", "group__aln__utils.html#ga7b61662a793ad0aa1ea38efc3a5baacc", null ],
    [ "vrna_aln_mpi", "group__consensus__fold.html#ga20fd17bb27891009af7ce839f5386177", null ],
    [ "vrna_aln_pinfo", "group__aln__utils.html#gaf6421a1318586c59fea6a127ed9f65f3", null ],
    [ "get_mpi", "group__consensus__fold.html#gaa2d600be90844094ec145ea14a314d2f", null ],
    [ "encode_ali_sequence", "group__consensus__fold.html#gaa3e40277c837d6f7603afe319884c786", null ],
    [ "alloc_sequence_arrays", "group__consensus__fold.html#ga8a560930f7f2582cc3967723a86cfdfa", null ],
    [ "free_sequence_arrays", "group__consensus__fold.html#ga298a420a8c879202e2617b3f724fde38", null ]
];