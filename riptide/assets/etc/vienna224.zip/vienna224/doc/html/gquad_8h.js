var gquad_8h =
[
    [ "get_gquad_matrix", "group__loops.html#ga392e45c9615aa123737671603fa4203c", null ],
    [ "parse_gquad", "group__loops.html#gae41763215b9c64d2a7b67f0df8a28078", null ],
    [ "backtrack_GQuad_IntLoop", "group__loops.html#ga220c41e8dbcee940ac975b8ce88e55c5", null ],
    [ "backtrack_GQuad_IntLoop_L", "group__loops.html#ga7b371308fa5a45c7ac353ef6ed1014de", null ]
];