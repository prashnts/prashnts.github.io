var group__kl__neighborhood__pf =
[
    [ "2Dpfold.h", "2Dpfold_8h.html", null ],
    [ "vrna_sol_TwoD_pf_t", "group__kl__neighborhood__pf.html#structvrna__sol__TwoD__pf__t", [
      [ "k", "group__kl__neighborhood__pf.html#ad1f23b46dc4ebd373abdeb0382d87b83", null ],
      [ "l", "group__kl__neighborhood__pf.html#a01133c264eff2c988d144e07803d1b8b", null ],
      [ "q", "group__kl__neighborhood__pf.html#a17ebbf425b8769ded74b5c7b85e58ee1", null ]
    ] ],
    [ "vrna_sol_TwoD_pf_t", "group__kl__neighborhood__pf.html#ga5e449fbd695406aabd2bcabddc374621", null ],
    [ "vrna_pf_TwoD", "group__kl__neighborhood__pf.html#ga0bc3427689bd09da09b8b3094a27f836", null ]
];