var group__pf__cofold_structvrna__dimer__pf__s =
[
    [ "F0AB", "group__pf__cofold.html#a82e31d1fb6e95923fab6036f52c370af", null ],
    [ "FAB", "group__pf__cofold.html#a01a87f59db2b7fbf883b056e6f6c673a", null ],
    [ "FcAB", "group__pf__cofold.html#a7b01cea5721f61badebc29cf0a9c4266", null ],
    [ "FA", "group__pf__cofold.html#a1aca57247f2c023d08028b1919005b0a", null ],
    [ "FB", "group__pf__cofold.html#ab4d307be5400604d3c1d84d58a9981df", null ]
];