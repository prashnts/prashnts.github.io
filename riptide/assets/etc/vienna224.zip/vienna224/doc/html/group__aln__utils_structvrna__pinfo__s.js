var group__aln__utils_structvrna__pinfo__s =
[
    [ "i", "group__aln__utils.html#ab91db0a87ef8402dc151795ba5a64c6f", null ],
    [ "j", "group__aln__utils.html#a4142e38d6ba127acccdf680300a88e1f", null ],
    [ "p", "group__aln__utils.html#a71990eae41fa100db8b557e4512ec281", null ],
    [ "ent", "group__aln__utils.html#a5ab2a63f3da8e12c6d54d8e9dd9e3e73", null ],
    [ "bp", "group__aln__utils.html#aa5feac5559b36dcd7cb38111c45d444d", null ],
    [ "comp", "group__aln__utils.html#a0720ae74ce53802a759ee9f98e9c8c43", null ]
];