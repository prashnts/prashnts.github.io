var group__kl__neighborhood__mfe_structvrna__sol__TwoD__t =
[
    [ "k", "group__kl__neighborhood__mfe.html#ac111e850bb3b3a11b6b5707912cfa1b8", null ],
    [ "l", "group__kl__neighborhood__mfe.html#ab8e95cd920901175a2cc8de726ab1d36", null ],
    [ "en", "group__kl__neighborhood__mfe.html#a7577863a6a84224dfee39b321c03cab1", null ],
    [ "s", "group__kl__neighborhood__mfe.html#ac5942d2505a6cd7e4a8073a321d5d2d5", null ]
];