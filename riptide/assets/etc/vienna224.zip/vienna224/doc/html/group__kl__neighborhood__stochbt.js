var group__kl__neighborhood__stochbt =
[
    [ "vrna_pbacktrack_TwoD", "group__kl__neighborhood__stochbt.html#ga14aceef73f83bbde77bb3a0ca06c9d13", null ],
    [ "vrna_pbacktrack5_TwoD", "group__kl__neighborhood__stochbt.html#ga6504913303bc325659c365d5f59b41e0", null ]
];