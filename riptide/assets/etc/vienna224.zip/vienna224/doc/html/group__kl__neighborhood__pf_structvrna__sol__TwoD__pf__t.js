var group__kl__neighborhood__pf_structvrna__sol__TwoD__pf__t =
[
    [ "k", "group__kl__neighborhood__pf.html#ad1f23b46dc4ebd373abdeb0382d87b83", null ],
    [ "l", "group__kl__neighborhood__pf.html#a01133c264eff2c988d144e07803d1b8b", null ],
    [ "q", "group__kl__neighborhood__pf.html#a17ebbf425b8769ded74b5c7b85e58ee1", null ]
];