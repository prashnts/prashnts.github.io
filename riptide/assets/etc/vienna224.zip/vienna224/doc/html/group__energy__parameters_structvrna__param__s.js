var group__energy__parameters_structvrna__param__s =
[
    [ "temperature", "group__energy__parameters.html#aeed2cd83713012bcb52e431041e037c8", null ],
    [ "model_details", "group__energy__parameters.html#a7b84353eb9075c595bad4ceb871bcae7", null ]
];