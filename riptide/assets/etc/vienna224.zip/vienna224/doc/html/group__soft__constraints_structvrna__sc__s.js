var group__soft__constraints_structvrna__sc__s =
[
    [ "energy_up", "group__soft__constraints.html#a57e4dbb924ab11f304e3762a3a9b07a1", null ],
    [ "energy_bp", "group__soft__constraints.html#ad139b8e06632e00cbcf3909815d0d03d", null ],
    [ "exp_energy_up", "group__soft__constraints.html#ad3b4972d3b6c23865587e4ac56a37375", null ],
    [ "exp_energy_bp", "group__soft__constraints.html#a62c22be478cd630541c91f73e6cb0d75", null ],
    [ "energy_stack", "group__soft__constraints.html#ac20dded6068e81acd0f1139092f66a22", null ],
    [ "exp_energy_stack", "group__soft__constraints.html#a4a0058fe3d5ba3416f0aaab677610115", null ],
    [ "f", "group__soft__constraints.html#a32dc86090237888c75491bbd4861a04b", null ],
    [ "bt", "group__soft__constraints.html#a2a2aca01782c2b980d7b7fd05b9be89c", null ],
    [ "exp_f", "group__soft__constraints.html#a0de08a09f3ccf2f97974d23192668ab0", null ],
    [ "data", "group__soft__constraints.html#a7574680143df97b9029146c2150bf06d", null ]
];