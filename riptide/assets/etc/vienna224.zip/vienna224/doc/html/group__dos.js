var group__dos =
[
    [ "density_of_states", "group__dos.html#ga937634a76b46a22530a74906f1957a9e", null ]
];