var group__subopt__zuker =
[
    [ "vrna_subopt_zuker", "group__subopt__zuker.html#gac0df98085abd242c7a6b1c868b3a35c8", null ],
    [ "zukersubopt", "group__subopt__zuker.html#ga0d5104e3ecf119d8eabd40aa5fe47f90", null ],
    [ "zukersubopt_par", "group__subopt__zuker.html#gab6d0ea8cc1d02f6dd831ca81043c9eb8", null ]
];