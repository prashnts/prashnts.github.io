var 2Dfold_8h =
[
    [ "vrna_sol_TwoD_t", "group__kl__neighborhood__mfe.html#ga6a81a58268d250309712549a3fa0aab2", null ],
    [ "TwoDfold_vars", "group__kl__neighborhood__mfe.html#gaf4f514010a14f9d59d850742b3e96954", null ],
    [ "vrna_mfe_TwoD", "group__kl__neighborhood__mfe.html#ga243c288b463147352829df04de6a2f77", null ],
    [ "vrna_backtrack5_TwoD", "group__kl__neighborhood__mfe.html#ga15a96fc96f4f4c2e01a11b3e17d1ef43", null ],
    [ "get_TwoDfold_variables", "group__kl__neighborhood__mfe.html#gac9284f132cf0eaa0a2f43590eda05488", null ],
    [ "destroy_TwoDfold_variables", "group__kl__neighborhood__mfe.html#ga05bf4f31d216b1b160fd2d3d68e9b487", null ],
    [ "TwoDfoldList", "group__kl__neighborhood__mfe.html#ga7fc5e3e92fe97914ca4eccd33c01c2a7", null ],
    [ "TwoDfold_backtrack_f5", "group__kl__neighborhood__mfe.html#gaf4dc05bf8fc1ea53acd7aeb798ba80c2", null ]
];